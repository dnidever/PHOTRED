#!/bin/sh
#curdir=`pwd`
#cd ~/idl/
#cat ${curdir}/idlastro.lst | xargs -n1 find -name
#cd ${curdir}
cat idlastro.lst | xargs -n1 find -name

